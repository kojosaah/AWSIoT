//import required modules

var awsIot = require('aws-iot-device-sdk');
var rpio = require('rpio');
var PythonShell = require('python-shell');

//initialize GPIO18 to low
rpio.open(12, rpio.OUTPUT, rpio.LOW);

//setup paths to certificates
var device = awsIot.device({
   keyPath: '/home/pi/finalProject/certs/6e38ac1a21-private.pem.key',
  certPath: '/home/pi/finalProject/certs/6e38ac1a21-certificate.pem.crt',
    caPath: '/home/pi/finalProject/certs/rootCA.pem',
  clientId: '935837496482',
   host:    'a3150yagsn4q7t.iot.eu-west-1.amazonaws.com',
    region: 'eu-west-1'
});

device
  .on('connect', function() {

    // subscribe to the LED topic
    device.subscribe('LED');
    // device.publish('LED', JSON.stringify({ light: 1}));
    });

device
  .on('message', function(topic, payload) {

    // convert the payload to a JSON object
    var payload = JSON.parse(payload.toString());

    console.log(payload.light);

    //check for TOPIC name
    if(topic == 'LED'){

        if(payload.light === 1){

          rpio.write(12, rpio.HIGH);

        } else if(payload.light === 0) {

          rpio.write(12, rpio.LOW);

        } else {
            console.log('Unknown Value :(');
        }
		
		// record and send mail if topic fits
		if(payload.cam === 1){
			PythonShell.run('cam_mail.py', function (err, results) {
			console.log(err);
			});
		}
    }
  });